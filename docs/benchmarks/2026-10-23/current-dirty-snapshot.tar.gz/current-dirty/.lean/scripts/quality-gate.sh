#!/usr/bin/env bash
# Project checks; --claude-hook adds transcript checks and local state.
# Cache is opt-in (--cache-tree) for checks depending only on Git-visible files: a pass made
# with it, direct or Stop, is reused by a later --cache-tree run on the same shipping state.
# Refusals never become passes. Local receipts catch drift, not hostile writers.

set -u
gate_args=("$@")

hook=0
seed=0
cache_tree=0
require_review=0
quiet=0
contract=""
session=""  # From the hook payload, or --session for a direct run.
session_contract=""  # Resolved from the guard's store by session id; never taken from the command line.
helper="$(cd "$(dirname "$0")" && pwd)/gate_evidence.py"
root="$(pwd)"
while [ "$#" -gt 0 ]; do
  case "$1" in
    --claude-hook) hook=1; shift ;;
    --seed) seed=1; shift ;;
    --cache-tree) cache_tree=1; shift ;;
    --require-review) require_review=1; shift ;;
    --quiet) quiet=1; shift ;;
    --contract)
      [ "$#" -ge 2 ] || { echo "--contract requires a line" >&2; exit 2; }
      contract="$2"; shift 2 ;;
    --session)
      [ "$#" -ge 2 ] || { echo "--session requires an id" >&2; exit 2; }
      session="$2"; shift 2 ;;
    --root)
      [ "$#" -ge 2 ] || { echo "--root requires a path" >&2; exit 2; }
      root="$2"; shift 2 ;;
    *) echo "Unknown gate option: $1" >&2; exit 2 ;;
  esac
done
[ "$seed" -eq 0 ] || [ "$hook" -eq 1 ] || { echo "--seed requires --claude-hook" >&2; exit 2; }
[ "$hook" -eq 0 ] || quiet=1  # No one watches a Stop hook live.
root="$(cd "$root" && pwd)" || exit 2
lock_helper="$(dirname "$helper")/gate_lock.py"
if ! python3 "$lock_helper" --check "$root"; then
  # Bash 3.2 (macOS /bin/bash) treats an empty "${gate_args[@]}" as unbound under set -u.
  exec python3 "$lock_helper" --run "$root" "$0" ${gate_args[@]+"${gate_args[@]}"}
fi
project="$root/.lean/PROJECT.md"
cache="$root/.claude/.gate-cache"
failed="$root/.claude/.gate-failed"
baseline="$root/.agent-runtime/gate-baseline"
refusal="$root/.agent-runtime/gate-refusal"
[ "$hook" -eq 0 ] || mkdir -p "$root/.claude" || exit 2

active=0
transcript=""
errlog=""
if [ "$hook" -eq 1 ] && [ "$seed" -eq 0 ]; then
  input="$(cat)"

  active="$(printf '%s' "$input" | python3 "$helper" --root "$root" hook-field --field stop_hook_active)" || exit 2
  transcript="$(printf '%s' "$input" | python3 "$helper" --root "$root" hook-field --field transcript_path)" || exit 2
  session="$(printf '%s' "$input" | python3 "$helper" --root "$root" hook-field --field session_id)" || exit 2
  # Keep this run's messages so a refusal is fingerprinted by its reason; they still reach
  # stderr when the run ends.
  errlog="$(mktemp "${TMPDIR:-/tmp}/lean-gate.XXXXXX")" || exit 2
  exec 3>&2 2>"$errlog"
  trap 'cat "$errlog" >&3; rm -f "$errlog"' EXIT
fi

# Progress is diagnostic only: Stop hooks and --quiet runs omit it, so a refusal carries only its failure.
progress() {
  [ "$quiet" -eq 0 ] || return 0
  printf 'Quality Gate: %s\n' "$1" >&2
}

# Record a refusal; $1 is "c" for a contract refusal, empty for a gate failure.
# A continuation adds to the count; a fresh Stop starts it at 1. A contract
# refusal says nothing about the code, so it keeps the passing-state cache and a
# later session's seed clears it instead of declining.
# After max_refusals continued refusals the Stop is released so the agent can
# report BLOCKED instead of looping; the release tells the user the work is
# unverified, keeps the refusal marker and never writes a cache or receipt.
max_refusals=3
refuse() {
  # Any run that refuses for a reason other than the contract drops the recorded pass, so no
  # later --cache-tree run reuses a state this one could not pass.
  [ "${1:-}" = "c" ] || [ "$seed" -eq 1 ] || rm -f "$cache"
  [ "$hook" -eq 1 ] && [ "$seed" -eq 0 ] || return 0
  local n=0
  if [ "$active" -eq 1 ]; then
    n="$(cat "$failed" 2>/dev/null)"
    n="${n#c}"
    case "$n" in ''|*[!0-9]*) n=0 ;; esac
  fi
  n=$((n + 1))
  printf '%s' "${1:-}$n" > "$failed"
  # This session has already been shown this exact refusal (same reason, shipping state and
  # contract); blocking every Stop while the agent waits on the user only loops, so warn instead.
  # A contract refusal keeps the cap below: the agent can fix it in its next reply, which the
  # state does not show.
  local print reason
  if [ "${1:-}" != "c" ] && [ -n "$session" ] && reason="$(cksum < "$errlog")" &&
     print="$(python3 "$helper" --root "$root" gate-state 2>/dev/null)" && [ -n "$print" ]; then
    print="$session $print $reason $contract"
    if [ -f "$refusal" ] && [ "$(cat "$refusal")" = "$print" ]; then
      printf '{"systemMessage":"Lean Quality Gate refused again with nothing changed since the last refusal; Stop released UNVERIFIED. The work is not DONE; see that refusal."}\n'
      exit 0
    fi
    mkdir -p "$(dirname "$refusal")" && printf '%s' "$print" > "$refusal"
  fi
  if [ "$n" -gt "$max_refusals" ]; then
    printf '{"systemMessage":"Lean Quality Gate still refused after %s attempts; Stop released UNVERIFIED. The work is not DONE; see the last gate refusal."}\n' "$max_refusals"
    exit 0
  fi
}

# A gate refusal is outstanding: the marker exists and is not a contract one.
gate_refused() {
  [ -f "$failed" ] && case "$(cat "$failed" 2>/dev/null)" in c*) return 1 ;; *) return 0 ;; esac
}

# Application checks must run before the Lean cache can skip its own checks.
# Target state (including untracked files) is separate from the superproject.
if [ "$seed" -eq 0 ] && { [ -e "$root/.agent-runtime/active-target.json" ] || [ -L "$root/.agent-runtime/active-target.json" ]; }; then
  progress "target checks started"
  target=(gate --optional)
  [ "$quiet" -eq 0 ] || target+=(--quiet)
  python3 "$root/.lean/scripts/submodule.py" --root "$root" "${target[@]}" || { refuse; exit 2; }
  progress "target checks passed"
fi

# The contract a session declared through the PreToolUse guard, read from the guard's store by
# session id (a hook payload or --session). Only a receipt for that contract can accept changed
# controls: the guard stops the author's main thread recording one for it, while an explicit --contract or a
# receipt's own contract is text anyone may have written.
if [ -n "$session" ]; then
  session_contract="$(python3 "$(dirname "$helper")/contract_guard.py" --root "$root" current --session "$session" 2>/dev/null)" ||
    session_contract=""
fi
# For a hook Stop that contract is the session's contract; the transcript is only a fallback,
# because a runtime may not persist every text block.
declared=""
if [ "$hook" -eq 1 ] && [ -z "$contract" ] && [ -n "$session_contract" ]; then
  declared="$session_contract"
  contract="$declared"
fi
# Name any High-risk review still ahead in the same refusal, so both steps are asked for at once.
guard_args=()
[ -z "$session_contract" ] || guard_args=(--contract "$session_contract")
if ! python3 "$helper" --root "$root" guard-controls ${guard_args[@]+"${guard_args[@]}"}; then
  pending="$(python3 "$helper" --root "$root" high-risk 2>/dev/null)" || pending=""
  [ -z "$pending" ] || { echo "After that, HIGH independent review is also required for these High-risk changes:"; printf '%s\n' "$pending"; } >&2
  refuse; exit 2
fi
[ -f "$project" ] || { echo "Quality Gate undefined: missing .lean/PROJECT.md; run /lean-init." >&2; refuse; exit 2; }

commands="$(awk '
  /<!-- gate:start -->/ { starts++; on = 1; next }
  /<!-- gate:end -->/   { ends++; if (!on) invalid=1; on = 0 }
  on && !/^```/ && !/^[[:space:]]*(#|$)/ { print }
  END { if (starts != 1 || ends != 1 || invalid) exit 2 }
' "$project")" || { echo "Quality Gate undefined: malformed gate markers." >&2; refuse; exit 2; }

[ -n "$commands" ] || { echo "Quality Gate undefined: configure checks in .lean/PROJECT.md; no validation passed." >&2; refuse; exit 2; }

cd "$root" || { refuse; exit 2; }

# The gate cache and baseline cover HEAD, index, Git-visible files, modes and submodule work.
state=""
if [ "$hook" -eq 1 ] && git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  state="$(python3 "$helper" --root "$root" gate-state)" || { refuse; exit 2; }
fi
# The state a pass is recorded under. A direct --cache-tree run fingerprints it only for that
# record: it never compares with the session baseline, so the High-risk floor still covers it.
pass_state="$state"
if [ "$hook" -eq 0 ] && [ "$cache_tree" -eq 1 ] && git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  pass_state="$(python3 "$helper" --root "$root" gate-state)" || { refuse; exit 2; }
fi

# SessionStart records a change baseline, never a passing cache.
if [ "$seed" -eq 1 ]; then
  # A new session has not seen any earlier refusal, so its first one blocks again.
  rm -f "$refusal"
  gate_refused && exit 0
  rm -f "$failed"
  if [ -n "$state" ]; then
    printf '%s' "$state" > "$baseline"
    git rev-parse -q --verify HEAD > "$baseline-head" 2>/dev/null || rm -f "$baseline-head"
  fi
  exit 0
fi

# A baseline can identify chat-only turns; it is never proof of validation.
changed=1
for prior in "$baseline" "$cache"; do
  if [ -n "$state" ] && [ -f "$prior" ] && [ "$(cat "$prior")" = "$state" ]; then changed=0; fi
done
if [ "$hook" -eq 1 ] && [ -z "$declared" ] && [ -n "$transcript" ]; then
  if [ ! -r "$transcript" ]; then
    echo "Contract transcript unreadable: $transcript" >&2
    refuse c; exit 2
  fi
  if found="$(python3 "$helper" --root "$root" contract --transcript "$transcript")"; then
    contract="$found"
  elif [ "$changed" -eq 1 ]; then
    refuse c; exit 2
  fi
fi
case "$contract" in
  "Contract: risk=HIGH quality="*|"Contract: risk=LOW quality=VERY_HIGH acceptance="*|"Contract: risk=MEDIUM quality=VERY_HIGH acceptance="*) require_review=1 ;;
esac

# PROJECT.md High-risk areas set a review floor that a self-declared risk cannot lower.
# An unchanged state matches the session baseline or a pass that already applied it.
risky=""
if [ "$changed" -eq 1 ]; then
  risky="$(python3 "$helper" --root "$root" high-risk)" || { refuse; exit 2; }
fi

# Explain a refused review receipt, naming any High-risk areas that required it.
review_refused() {
  [ -z "$risky" ] || { echo "High-risk areas changed; HIGH independent review is required:"; printf '%s\n' "$risky"; } >&2
  refuse
  exit 2
}

# A HIGH contract needs a receipt for itself. The High-risk floor needs only that the state
# which ships was reviewed: a later contract that changes nothing ships that reviewed state.
check_receipt() {
  if [ "$require_review" -eq 1 ]; then
    python3 "$helper" --root "$root" check-review --contract "$contract" || review_refused
  elif [ -n "$risky" ]; then
    # A receipt for this exact contract, or a HIGH-depth receipt for exactly this state.
    python3 "$helper" --root "$root" check-review --contract "$contract" 2>/dev/null ||
      python3 "$helper" --root "$root" check-shipped || review_refused
  fi
}

# Only a real passing run can be cached; contracts and HIGH review are checked first.
# A direct run's record is marked: it never read the transcript, so it can skip the commands but
# never makes changed work count as unchanged for the contract check above.
if [ "$cache_tree" -eq 1 ] && [ -n "$pass_state" ] && [ ! -f "$failed" ] && [ -f "$cache" ] &&
   { [ "$(cat "$cache")" = "$pass_state" ] || [ "$(cat "$cache")" = "direct $pass_state" ]; }; then
  check_receipt
  # This Stop has now checked the contract for that state, so the record stands as a Stop's pass.
  [ "$hook" -eq 0 ] || printf '%s' "$pass_state" > "$cache"
  exit 0
fi

check_number=0
while IFS= read -r cmd; do
  check_number=$((check_number + 1))
  progress "check $check_number started"
  started=$SECONDS
  if output="$(bash -c "$cmd" 2>&1)"; then
    progress "check $check_number passed ($((SECONDS - started))s)"
    continue
  else
    status=$?
  fi

  # 127 identifies a missing tool only when its plain command name cannot
  # resolve. Wrappers, paths and shell fragments retain the failure verdict.
  # Skip leading simple VAR=VALUE words before looking up the command.
  lookup="$cmd"
  while [[ "$lookup" =~ ^[[:space:]]*[A-Za-z_][A-Za-z0-9_]*=[^[:space:]]*[[:space:]]+(.*)$ ]]; do
    lookup="${BASH_REMATCH[1]}"
  done
  read -r first _ <<< "$lookup"

  missing=0
  if [ "$status" -eq 127 ] &&
     [[ "$first" =~ ^[A-Za-z0-9_][A-Za-z0-9_.+:@-]*$ ]] &&
     ! command -v -- "$first" >/dev/null 2>&1; then
    missing=1
  fi

  {
    if [ "$missing" -eq 1 ]; then
      echo "Quality Gate could not run: $cmd"
      printf '%s\n' "$output" | tail -n 40
      echo "'$first' is not available in this environment, so this check never ran. That is a missing tool, not a failure your change caused. Do not edit code, the gate, or the tests to get past it: report BLOCKED, name the gate command that could not run and the tool it needs, say the change is unverified by that command, and do not declare DONE."
    elif python3 "$(dirname "$helper")/gate_mode.py" --root "$root" --fixloop >/dev/null 2>&1; then
      echo "Quality Gate failed: $cmd"
      printf '%s\n' "$output" | tail -n 40
      echo "Fixloop mode is active: fix all actionable code, test and lint failures and re-run the Quality Gate until it passes without asking the user, stopping only for a genuine requirement/design question. Do not declare DONE until the gate passes."
    else
      echo "Quality Gate failed: $cmd"
      printf '%s\n' "$output" | tail -n 40
      echo "If your change caused this, fix it. If it was already failing or is outside the task, do not touch it: report BLOCKED and ask. Do not declare DONE."
    fi
  } >&2
  refuse
  exit 2
done <<< "$commands"

check_receipt
# A pass ends any standing refusal; a run that fingerprinted the state records the pass.
if [ "$hook" -eq 1 ] || [ -n "$pass_state" ]; then rm -f "$failed" "$refusal"; fi
if [ -n "$pass_state" ]; then
  record="$pass_state"
  [ "$hook" -eq 1 ] || record="direct $pass_state"
  mkdir -p "$root/.claude" && printf '%s' "$record" > "$cache"
fi
exit 0
